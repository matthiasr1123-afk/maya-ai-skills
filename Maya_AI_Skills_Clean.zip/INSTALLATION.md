# How to use

These are instruction templates, not installed plugins. GitHub storage alone does not activate them.

1. Upload this ZIP to your GitHub repository or extract its files into your repo.
2. Copy the relevant Markdown instructions into your ChatGPT Project instructions or compatible agent environment.
3. Keep product research separate from Gemini prompt writing.
4. Test a skill on one real task and revise based on observed results.
5. Do not run unreviewed repository scripts.
